#!/usr/bin/env python3
a = 15
def square_perimeter(a=a):
    return 4 * a


def square_area(a=a):
    return a ** 2
